<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>

<section class="py-10 d-flex items-center bg-light-2">
  <div class="container">
    <div class="row y-gap-10 items-center justify-between">
      <div class="col-auto">
        <div class="row x-gap-10 y-gap-5 items-center text-14 text-light-1">
          <div class="col-auto">
            <div class=""><?php echo e(translate('home')); ?></div>
          </div>
          <div class="col-auto">
            <div class="">></div>
          </div>
          <div class="col-auto">
            <div class=""><?php echo e($restaurant->name); ?></div>
          </div>
          <div class="col-auto">
            <div class="">></div>
          </div>
          <div class="col-auto">
            <div class="text-dark-1"><?php echo e($restaurant->address); ?></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="pt-40">
  <div class="container">
    <div class="row y-gap-20 justify-between items-end">
      <div class="col-auto">
        <div class="row x-gap-20 items-center">
          <div class="col-auto">
            <h1 class="text-30 sm:text-25 fw-600"><?php echo e($restaurant->name); ?></h1>
          </div>
          <!-- 
          <div class="col-auto">
            <i class="icon-star text-10 text-yellow-1"></i>

            <i class="icon-star text-10 text-yellow-1"></i>

            <i class="icon-star text-10 text-yellow-1"></i>

            <i class="icon-star text-10 text-yellow-1"></i>

            <i class="icon-star text-10 text-yellow-1"></i>
          </div> -->
        </div>

        <div class="row x-gap-20 y-gap-20 items-center">
          <div class="col-auto">
            <div class="d-flex items-center text-15 text-light-1">
              <i class="icon-location-2 text-16 mr-5"></i>
              <?php echo e($restaurant->address); ?>

            </div>
          </div>

          <!-- <div class="col-auto">
                <button data-x-click="mapFilter" class="text-blue-1 text-15 underline">Show on map</button>
              </div> -->
        </div>
      </div>

      <div class="col-auto">
        <div class="row x-gap-15 y-gap-15 items-center">
          <div class="col-auto">
            <div class="text-14">
              From
              <span class="text-22 text-dark-1 fw-500">¥<?php echo e(number_format($restaurant->price_range)); ?></span>
            </div>
          </div>

          <div class="col-auto">
            <a href="<?php echo e(route('booking.detail', ['id' => $restaurant->id])); ?>"
              class="button h-50 px-24 -dark-1 bg-blue-1 text-white">
              Booking
              <div class="icon-arrow-top-right ml-15"></div>
            </a>
          </div>
        </div>
      </div>
    </div>

    <div class="galleryGrid -type-1 pt-30">
      <div class="galleryGrid__item relative d-flex">
        <?php if($restaurant->multi_images): ?> <?php $images = is_string($restaurant->multi_images) ? json_decode($restaurant->multi_images) : $restaurant->multi_images; $firstImage = $images[0] ?? null; ?> <?php if($firstImage): ?>
        <img src="<?php echo e(asset($firstImage)); ?>" alt="Restaurant Image" class="rounded-4" />
        <?php endif; ?> <?php endif; ?>

        <div class="cardImage__wishlist">
                      <button class="button -blue-1 bg-white size-30 rounded-full shadow-2 favourite-btn" data-id="<?php echo e($restaurant->id); ?>">
                        <i class="icon-heart text-12"></i>
                      </button>
                    </div>
      </div>

      <div class="galleryGrid__item">
        <?php if($restaurant->multi_images): ?> <?php $images = is_string($restaurant->multi_images) ? json_decode($restaurant->multi_images) : $restaurant->multi_images; $firstImage = $images[1] ?? null; ?> <?php if($firstImage): ?>
        <img src="<?php echo e(asset($firstImage)); ?>" alt="image" class="rounded-4" />
        <?php endif; ?> <?php endif; ?>
      </div>

      <div class="galleryGrid__item relative d-flex">
        <?php if($restaurant->multi_images): ?> <?php $images = is_string($restaurant->multi_images) ? json_decode($restaurant->multi_images) : $restaurant->multi_images; $firstImage = $images[2] ?? null; ?> <?php if($firstImage): ?>
        <img src="<?php echo e(asset($firstImage)); ?>" alt="image" class="rounded-4" />
        <?php endif; ?> <?php endif; ?>
        <div class="galleryGrid__item">
          <?php if($restaurant->multi_images): ?> <?php $images = is_string($restaurant->multi_images) ? json_decode($restaurant->multi_images) : $restaurant->multi_images; $firstImage = $images[3] ?? null; ?> <?php if($firstImage): ?>
          <img src="<?php echo e(asset($firstImage)); ?>" alt="image" class="rounded-4" />
          <?php endif; ?> <?php endif; ?>
        </div>
      </div>

      <div class="galleryGrid__item">
        <?php if($restaurant->multi_images): ?> <?php $images = is_string($restaurant->multi_images) ? json_decode($restaurant->multi_images) : $restaurant->multi_images; $firstImage = $images[4] ?? null; ?> <?php if($firstImage): ?>
        <img src="<?php echo e(asset($firstImage)); ?>" alt="image" class="rounded-4" />
        <?php endif; ?> <?php endif; ?>
      </div>

      <div class="galleryGrid__item relative d-flex">
        <?php if($restaurant->multi_images): ?> <?php $images = is_string($restaurant->multi_images) ? json_decode($restaurant->multi_images) : $restaurant->multi_images; $firstImage = $images[4] ?? null; ?> <?php if($firstImage): ?>
        <img src="<?php echo e(asset($firstImage)); ?>" alt="image" class="rounded-4" />
        <?php endif; ?> <?php endif; ?> <?php if($restaurant->multi_images): ?> <?php $images = is_string($restaurant->multi_images) ? json_decode($restaurant->multi_images) : $restaurant->multi_images; $firstImage = $images[0] ?? null; ?>
        <?php if($firstImage): ?>
        <div class="absolute px-10 py-10 col-12 h-full d-flex justify-end items-end">
          <a href="<?php echo e(asset($firstImage)); ?>" class="button -blue-1 px-24 py-15 bg-white text-dark-1 js-gallery" data-gallery="gallery2">
            <?php echo e(translate('see_all')); ?> <?php echo e(count($images)); ?> <?php echo e(translate('photos')); ?>

          </a>

          <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(asset($image)); ?>" class="js-gallery" data-gallery="gallery2"></a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?> <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<section class="pt-30">
  <div class="container">
    <div class="row y-gap-30">
      <div class="col-xl-8">
        <div class="row y-gap-40">
          <div class="col-12">
            <h3 class="text-22 fw-500"><?php echo e(translate('property_highlights')); ?></h3>
            <div class="row y-gap-20 pt-30">
              <div class="col-lg-3 col-6">
                <div class="text-center">
                  <i class="icon-kitchen text-24 text-blue-1"></i>
                  <div class="text-15 lh-1 mt-10"><?php echo e($restaurant->category->name); ?></div>
                </div>
              </div>

              <div class="col-lg-3 col-6">
                <div class="text-center">
                  <i class="icon-bell-ring text-24 text-blue-1"></i>
                  <div class="text-15 lh-1 mt-10"><?php echo e(translate('operating_hours')); ?> [<?php echo e($restaurant->operating_hours); ?>]</div>
                </div>
              </div>
            </div>
          </div>

          <div id="overview" class="col-12">
            <h3 class="text-22 fw-500 pt-40 border-top-light"><?php echo e(translate('overview')); ?></h3>
            <p class="text-dark-1 text-15 mt-20">
              <?php echo e($restaurant->description); ?>

            </p>

          </div>
          <div class="col-md">

            <div class="row x-gap-10 y-gap-10 pt-20">

              <?php if($restaurant->wifi_availability): ?>
              <div class="col-auto">
                <div class="border-light rounded-100 py-5 px-20 text-14 lh-14"><?php echo e(translate('wifi')); ?></div>
              </div>
              <?php endif; ?>
              <?php if($restaurant->parking_availability): ?>

              <div class="col-auto">
                <div class="border-light rounded-100 py-5 px-20 text-14 lh-14"><?php echo e(translate('parking')); ?></div>
              </div>
              <?php endif; ?>
              <?php if($restaurant->outdoor_seating): ?>

              <div class="col-auto">
                <div class="border-light rounded-100 py-5 px-20 text-14 lh-14"><?php echo e(translate('outdoor_seat')); ?></div>
              </div>
              <?php endif; ?>

              <!-- <div class="col-auto">
                <div class="border-light rounded-100 py-5 px-20 text-14 lh-14"><?php echo e($restaurant->available); ?></div>
              </div> -->
            </div>
          </div>

          <div class="col-12">
            <h3 class="text-22 fw-500"><?php echo e(translate('contact_us')); ?></h3>
            <div class="row y-gap-20 pt-30">
              <div class="col-lg-3 col-6">
                <div class="text-center">
                  <i class="icon-city text-24 text-blue-1"></i>
                  <div class="text-15 lh-1 mt-10"><?php echo e($restaurant->city); ?></div>
                </div>
              </div>

              <div class="col-lg-3 col-6">
                <div class="text-center">
                  <i class="icon-nearby text-24 text-blue-1"></i>
                  <div class="text-15 lh-1 mt-10"><?php echo e(translate('phone')); ?> - <?php echo e($restaurant->phone_number); ?></div>
                </div>
              </div>

              <div class="col-lg-3 col-6">
                <div class="text-center">
                  <i class="icon-newsletter text-24 text-blue-1"></i>
                  <div class="text-15 lh-1 mt-10"><?php echo e(translate('email')); ?> - <?php echo e($restaurant->email); ?></div>
                </div>
              </div>

              <div class="col-lg-3 col-6">
                <div class="text-center">
                  <i class="icon-city text-24 text-blue-1"></i>
                  <div class="text-15 lh-1 mt-10"><?php echo e(translate('address')); ?> - <?php echo e($restaurant->address); ?></div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-12">
            <h3 class="text-22 fw-500 pt-40 border-top-light">メニュー</h3>

            <?php if($menus->isEmpty()): ?>
            <p class="text-center text-muted mt-3">メニューが見つかりません。</p>
            <?php else: ?>
            <div class="row g-3 mt-3">
              <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4 col-sm-6">
                <div class="card border-0 shadow-sm">
                  <img src="<?php echo e(asset($menu->image)); ?>" class="card-img-top rounded-top" alt="<?php echo e($menu->name); ?>">
                  <div class="card-body text-center">
                    <h5 class="fw-bold text-dark"><?php echo e($menu->menu); ?></h5>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
          </div>


        </div>
      </div>

      <div class="col-xl-4">
        <div class="ml-50 lg:ml-0">
        

          <div class="px-30 py-30 border-light rounded-4 mt-30">
            <div class="flex-center ratio ratio-15:9 mb-15 js-lazy" data-bg="img/general/map.png')}}">
              <a href="<?php echo e($restaurant -> google_map); ?>" class="button py-15 px-24 -blue-1 bg-white text-dark-1 absolute" target="_blank">
                <i class="icon-location text-22 mr-10"></i>
                <?php echo e(translate('show_on_map')); ?>

              </a>
            </div>

            <div class="row y-gap-10">
              <div class="col-12">
                <div class="d-flex items-center">
                  <i class="icon-award text-20 text-blue-1"></i>
                  <div class="text-14 fw-500 ml-10"><?php echo e(translate('location')); ?> - <?php echo e($restaurant->city); ?></div>
                </div>
              </div>
            </div>

            <div class="border-top-light mt-15 mb-15"></div>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<div id="reviews"></div>
<section class="mt-40">
  <?php echo $__env->make('includes.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script>
  document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#date-picker", {
      enableTime: true,
      dateFormat: "Y-m-d H:i",
      time_24hr: true,
      onClose: function(selectedDates) {
        if (selectedDates.length === 1) {
          document.getElementById("check_in").value = flatpickr.formatDate(selectedDates[0], "Y-m-d H:i");
        }
      }
    });
  });

  $(document).ready(function() {
    $('.favourite-btn').click(function(e) {
      e.preventDefault();

      let restaurantId = $(this).data('id');
      let token = '<?php echo e(csrf_token()); ?>';

      $.ajax({
        url: "<?php echo e(route('booking.favourite')); ?>",
        type: "GET",
        data: {
          _token: token,
          restaurants_id: restaurantId
        },
        success: function(response) {
          toastr.success(response.message);
        },
        error: function(xhr) {
          if (xhr.status === 422) {
            toastr.error("Invalid request. Please try again.");
          } else {
            toastr.error("'最初にログインする必要があります。");
          }
        }
      });
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\ticket\e-ticket-main\resources\views/restaurant-detail.blade.php ENDPATH**/ ?>