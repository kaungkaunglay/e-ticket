<!DOCTYPE html>
<html>
<head>
    <title>Subscription Confirmation</title>
</head>
<body>
    <h1>Thank you for subscribing!</h1>
    <p>We will send you updates and discounts at: <?php echo e($email); ?></p>
</body>
</html>
<?php /**PATH C:\project\ticket\e-ticket-main\resources\views/emails/subscription_confirmation.blade.php ENDPATH**/ ?>