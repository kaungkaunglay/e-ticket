<?php $__env->startSection('contents'); ?>

<div class="container text-center mt-5" style="padding: 100px;">

<h2>ありがとうございます！</h2>

<p>予約が正常に送信されました。</p>

<a href="<?php echo e(route('home')); ?>" class="button -md -dark-1 bg-red h-50 text-white mt-30">ホームへ戻る</a> 


</div>
<div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\ticket\e-ticket-main\resources\views/thank-you.blade.php ENDPATH**/ ?>