<?php $__env->startSection('content'); ?>

<div class="row y-gap-20 justify-between items-end pb-60 lg:pb-40 md:pb-32">
    <div class="col-auto">
        <h1 class="text-30 lh-14 fw-600"><?php echo e(isset($category) ? translate('edit') : translate('add')); ?> <?php echo e(translate('question')); ?> </h1>
    </div>
</div>

<div class="py-30 px-30 rounded-4 bg-white shadow-3">
    <div class="tabs -underline-2 js-tabs">
        <div class="tabs__content pt-30 js-tabs-content">
            <div class="tabs__pane -tab-item-1 is-tab-el-active">
                <div class="col-xl-10">
                    <div class="text-18 fw-500 mb-10"><?php echo e(translate('question_category')); ?> </div>

                    <?php if(session('success')): ?>
                        <div class="text-green-500"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(isset($category) ? route('support.updatecategory', $category->id) : route('support.storecategory')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($category)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>

                        <div class="row x-gap-20 y-gap-20">
                            <div class="col-12">
                                <div class="form-input">
                                    <input type="text" name="title" placeholder="<?php echo e(translate('name')); ?>" value="<?php echo e(old('title', isset($category) ? $category->title : '')); ?>" required>
                                </div>
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="d-inline-block pt-30">
                            <button type="submit" class="button h-50 px-24 -dark-1 bg-blue-1 text-white">
                                <?php echo e(translate('name')); ?><div class="icon-arrow-top-right ml-15"></div>
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('resturant.includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\ticket\e-ticket-main\resources\views/support/createcategory.blade.php ENDPATH**/ ?>