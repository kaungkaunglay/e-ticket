


<?php $__env->startSection('content'); ?>
<h1> Vendor</h1>
<?php $__env->stopSection(); ?>

<!-- 

<h1>Vendor admin</h1>
<a href="#" onclick="event.preventDefault(); document.getElementById('admin-logout-form').submit();">Logout</a>

<form id="admin-logout-form" method="POST" action="<?php echo e(route('vendor.logout')); ?>" style="display: none;">
    <?php echo csrf_field(); ?>
</form> -->

<?php echo $__env->make('resturant.includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\ticket\e-ticket-main\resources\views/vendor/dashboard.blade.php ENDPATH**/ ?>