<!DOCTYPE html>
<html>
<head>
    <title>予約確認</title>
    <meta charset="UTF-8">
</head>
<body>
    <h1>ご予約ありがとうございます！</h1>

    <!-- <p><?php echo e($booking->first_name); ?> 様</p> -->

    <p><strong><?php echo e($restaurant->name); ?></strong> へのご予約が確定いたしました。</p>

    <p><strong>ご予約内容：</strong></p>
    <ul>
        <li><strong>店舗名：</strong> <?php echo e($restaurant->name); ?></li>
        <li><strong>予約日時：</strong> <?php echo e($booking->select_date); ?></li>
        <li><strong>備考：</strong> <?php echo e($booking->note ?? '特別なリクエストなし'); ?></li>
    </ul>

    <p>ご来店を心よりお待ちしております。</p>

    <p>どうぞよろしくお願いいたします。</p>
    <p><?php echo e($restaurant->name); ?> スタッフ一同</p>
</body>
</html><?php /**PATH C:\project\ticket\e-ticket-main\resources\views/emails/booking_confirmation.blade.php ENDPATH**/ ?>