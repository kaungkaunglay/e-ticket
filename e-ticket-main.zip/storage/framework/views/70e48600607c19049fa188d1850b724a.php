<div class="sidebar -dashboard">

<div class="sidebar__item ">


  <a href="db-dashboard.html" class="sidebar__button d-flex items-center text-15 lh-1 fw-500">
    <img src="<?php echo e(asset('assets/img/dashboard/sidebar/compass.svg')); ?>" alt="image" class="mr-15">
    Dashboard
  </a>


</div>



<div class="sidebar__item ">


  <div class="accordion -db-sidebar js-accordion">
    <div class="accordion__item">
      <div class="accordion__button">
        <div class="sidebar__button col-12 d-flex items-center justify-between">
          <div class="d-flex items-center text-15 lh-1 fw-500">
            <img src="<?php echo e(asset('/assets/img/dashboard/sidebar/hotel.svg')); ?>" alt="image" class="mr-10">
            Manage Resturants Type
          </div>
          <div class="icon-chevron-sm-down text-7"></div>
        </div>
      </div>

      <div class="accordion__content">
        <ul class="list-disc pt-15 pb-5 pl-40">

          <li>
            <a href="<?php echo e(route('categories.index')); ?>" class="text-15">All Resturants Type</a>
          </li>

          <li>
            <a href="<?php echo e(route('categories.create')); ?>" class="text-15">Add Resturants Type</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
 
</div>
</div><?php /**PATH C:\project\ticket\e-ticket-main\resources\views/Layout/nav.blade.php ENDPATH**/ ?>