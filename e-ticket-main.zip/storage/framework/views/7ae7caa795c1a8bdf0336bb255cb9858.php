<?php $__env->startSection('content'); ?>
<div class="row y-gap-20 justify-between items-end pb-60 lg:pb-40 md:pb-32">
    <div class="col-auto">
        <h1 class="text-30 lh-14 fw-600"><?php echo e(translate('all_booking')); ?></h1>
    </div>

    <div class="col-auto">
        <!-- <a href="<?php echo e(locale_route('menu.manage')); ?>" class="button h-50 px-24 -dark-1 bg-blue-1 text-white">
            <?php echo e(translate('menu_create')); ?> <div class="icon-arrow-top-right ml-15"></div>
        </a> -->
    </div>
</div>

<div class="py-30 px-30 rounded-4 bg-white shadow-3">
    <div class="tabs -underline-2 js-tabs">
        <div class="tabs__controls row x-gap-40 y-gap-10 lg:x-gap-20 js-tabs-controls">
            <div class="col-auto">
                <button class="tabs__button text-18 lg:text-16 text-light-1 fw-500 pb-5 lg:pb-0 js-tabs-button is-tab-el-active" data-tab-target=".-tab-item-1"><?php echo e(translate('all_booking')); ?></button>
            </div>
        </div>

        <div class="tabs__content pt-30 js-tabs-content">
            <div class="tabs__pane -tab-item-1 is-tab-el-active">
                <div class="overflow-scroll scroll-bar-1">
                <table class="table table-striped">
    <thead>
        <tr>
            <th><?php echo e(translate('name')); ?></th>
            <th><?php echo e(translate('address')); ?></th>
            <!-- <th>City</th> -->
            <th><?php echo e(translate('phone')); ?></th>
            <th><?php echo e(translate('price')); ?></th>
            <!-- <th>Web Url</th> -->
            <th><?php echo e(translate('note')); ?></th>
            <th>Note</th>
            <th><?php echo e(translate('view')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
           
            <td><?php echo e($booking->restaurant_name); ?></td>
        
            <td><?php echo e($booking->restaurant_address); ?></td>
       
            <!-- <td><?php echo e($booking->city); ?></td> -->
        
            <td><?php echo e($booking->phone_number); ?></td>
           
            <td>¥<?php echo e(number_format($booking->price_range)); ?></td>
            <!-- <td><?php echo e($booking->website_url); ?></td> -->

        
            <td><?php echo e($booking->select_date); ?></td>
           
            <td><?php echo e($booking->note ?? 'No Note'); ?></td>

       
            <td>
                <a href="/restaurant/<?php echo e($booking->restaurant_id); ?>" title="View Restaurant">
                    <button class="button bg-red h-10 text-white" style="width: 72px;">
                        Preview
                    </button>
                </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

                </div>
            </div>
        </div>
    </div>

    <div class="pt-30 pagination d-flex">
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('resturant.includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\ticket\e-ticket-main\resources\views/resturant/booking.blade.php ENDPATH**/ ?>