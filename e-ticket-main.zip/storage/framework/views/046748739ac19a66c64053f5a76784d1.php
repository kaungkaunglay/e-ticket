
<?php $__env->startSection('content'); ?>

<div class="row y-gap-20 justify-between items-end pb-60 lg:pb-40 md:pb-32">
    <div class="col-auto">
        <h1 class="text-30 lh-14 fw-600"><?php echo e(isset($question) ? 'Edit' : 'Add'); ?> Question</h1>
    </div>
</div>

<?php if(session('success')): ?>
<div class="text-green-500"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="py-30 px-30 rounded-4 bg-white shadow-3">
    <form action="<?php echo e(isset($question) ? route('createsupport.storeOrUpdate', $question->id) : route('createsupport.storeOrUpdate')); ?>"
        method="POST" class="contact-form">
        <?php echo csrf_field(); ?>

        <div class="row x-gap-20 y-gap-20">

            <div class="col-12">
                <div class="form-input">
                    <select name="support_category" class="form-control" required>
                        <option value="">Select Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"
                            <?php echo e(isset($question) && $question->support_category == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->title); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>


            <div class="col-12">
                <div class="form-input">
                    <textarea name="description" required><?php echo e(old('description', isset($question) ? $question->description : '')); ?></textarea>
                    <label class="lh-1 text-16 text-light-1">Description</label>
                </div>
            </div>
        </div>

        <div class="d-inline-block pt-30">
            <button type="submit" class="button h-50 px-24 -dark-1 bg-blue-1 text-white">
                <?php echo e(isset($question) ? 'Update' : 'Add'); ?> Question
            </button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<style>
    .form-input {
        margin-bottom: 1rem;
    }

    .form-control {
        width: 100%;
        padding: 0.5rem;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    .error-message {
        font-size: 0.9rem;
        margin-top: 0.25rem;
    }
</style>
<?php echo $__env->make('resturant.includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\ticket\e-ticket-main\resources\views/support/postcreate.blade.php ENDPATH**/ ?>