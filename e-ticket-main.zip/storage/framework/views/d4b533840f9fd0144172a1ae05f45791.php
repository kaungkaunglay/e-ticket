<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
<section class="pt-40 pb-40 bg-light-2">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="text-center">
          <h1 class="text-30 fw-600"><?php echo e(translate('restaurant_near')); ?></h1>
        </div>

        
      </div>
    </div>
  </div>
</section>

<section class="layout-pt-md layout-pb-lg">
  <div class="container">
    <div class="row y-gap-30">
      <div class="col-xl-3 col-lg-4 lg:d-none">
        <aside class="sidebar y-gap-40">
          <div class="sidebar__item pb-30">
            <h5 class="text-18 fw-500 mb-10"><?php echo e(translate('price')); ?></h5>
            <div class="row x-gap-10 y-gap-30">
              <div class="col-12">
                <div class="js-price-rangeSlider">
                  <div class="text-14 fw-500"></div>

                  <div class="d-flex justify-between mb-20">
                    <div class="text-15 text-dark-1">
                      <span class="js-lower"></span>
                      -
                      <span class="js-upper"></span>
                    </div>
                  </div>

                  <div class="px-5">
                    <div class="js-slider"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          
          <div class="sidebar__item">
            <h5 class="text-18 fw-500 mb-10"><?php echo e(translate('style')); ?></h5>
            <div class="sidebar-checkbox">

              <div class="row y-gap-10 items-center justify-between">
                <div class="col-auto">

                  <div class="d-flex items-center">
                    <div class="form-checkbox ">
                      <input type="checkbox" name="name">
                      <div class="form-checkbox__mark">
                        <div class="form-checkbox__icon icon-check"></div>
                      </div>
                    </div>

                    <div class="text-15 ml-10"><?php echo e(translate('budget')); ?></div>

                  </div>

                </div>

                <div class="col-auto">
                  <div class="text-15 text-light-1">92</div>
                </div>
              </div>

              <div class="row y-gap-10 items-center justify-between">
                <div class="col-auto">

                  <div class="d-flex items-center">
                    <div class="form-checkbox ">
                      <input type="checkbox" name="name">
                      <div class="form-checkbox__mark">
                        <div class="form-checkbox__icon icon-check"></div>
                      </div>
                    </div>

                    <div class="text-15 ml-10"><?php echo e(translate('mid_range')); ?> </div>

                  </div>

                </div>

                <div class="col-auto">
                  <div class="text-15 text-light-1">45</div>
                </div>
              </div>

              <div class="row y-gap-10 items-center justify-between">
                <div class="col-auto">

                  <div class="d-flex items-center">
                    <div class="form-checkbox ">
                      <input type="checkbox" name="name">
                      <div class="form-checkbox__mark">
                        <div class="form-checkbox__icon icon-check"></div>
                      </div>
                    </div>

                    <div class="text-15 ml-10"><?php echo e(translate('luxury')); ?></div>

                  </div>

                </div>

                <div class="col-auto">
                  <div class="text-15 text-light-1">21</div>
                </div>
              </div>

              <div class="row y-gap-10 items-center justify-between">
                <div class="col-auto">

                  <div class="d-flex items-center">
                    <div class="form-checkbox ">
                      <input type="checkbox" name="name">
                      <div class="form-checkbox__mark">
                        <div class="form-checkbox__icon icon-check"></div>
                      </div>
                    </div>

                    <div class="text-15 ml-10"><?php echo e(translate('family_friendly')); ?></div>

                  </div>

                </div>

                <div class="col-auto">
                  <div class="text-15 text-light-1">78</div>
                </div>
              </div>

              <div class="row y-gap-10 items-center justify-between">
                <div class="col-auto">

                  <div class="d-flex items-center">
                    <div class="form-checkbox ">
                      <input type="checkbox" name="name">
                      <div class="form-checkbox__mark">
                        <div class="form-checkbox__icon icon-check"></div>
                      </div>
                    </div>

                    <div class="text-15 ml-10"><?php echo e(translate('business')); ?></div>

                  </div>

                </div>

                <div class="col-auto">
                  <div class="text-15 text-light-1">679</div>
                </div>
              </div>

            </div>
          </div>

        </aside>
      </div>

      <div class="col-xl-9 col-lg-8">
        <div class="row y-gap-10 items-center justify-between">
          <div class="col-auto">
            <!-- <div class="text-18"><span class="fw-500">3,269 properties</span> in Europe</div> -->
          </div>

          <div class="col-auto">
            <div class="row x-gap-20 y-gap-20">
              <div class="col-auto">
                <button class="button -blue-1 h-40 px-20 rounded-100 bg-blue-1-05 text-15 text-blue-1">
                  <i class="icon-up-down text-14 mr-10"></i>
                  <?php echo e(translate('top_picks_for_your_search')); ?>

                </button>
              </div>

              <div class="col-auto d-none lg:d-block">
                <button data-x-click="filterPopup" class="button -blue-1 h-40 px-20 rounded-100 bg-blue-1-05 text-15 text-blue-1">
                  <i class="icon-up-down text-14 mr-10"></i>
                  Filter
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class="mt-30"></div>

        <div class="row y-gap-30">

          <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-12">

              <div class="border-top-light pt-30">
                <div class="row x-gap-20 y-gap-20">
                  <div class="col-md-auto">

                    <div class="cardImage ratio ratio-1:1 w-250 md:w-1/1 rounded-4">
                      <div class="cardImage__content">
                        <img class="rounded-4 col-12" src="<?php echo e(asset('' . $restaurant->logo)); ?>" alt="<?php echo e($restaurant->name); ?> logo">
                      </div>

                      <div class="cardImage__wishlist">
                        <button class="button -blue-1 bg-white size-30 rounded-full shadow-2">
                          <i class="icon-heart text-12"></i>
                        </button>
                      </div>

                    </div>

                  </div>

                  <div class="col-md">
                    <h3 class="text-18 lh-16 fw-500">
                      <?php echo e($restaurant->name); ?><br class="lg:d-none"> <?php echo e($restaurant->category->name); ?>, <?php echo e($restaurant->city); ?>

                    </h3>

                    <div class="row x-gap-10 y-gap-10 items-center pt-10">
                      <div class="col-auto">
                        <p class="text-14"><?php echo e($restaurant->address); ?></p>
                      </div>

                      <div class="col-auto">
                        <a href="<?php echo e($restaurant->google_map); ?>" class="d-block text-14 text-blue-1 underline"><?php echo e(translate('show_on_map')); ?></a>
                      </div>
                    </div>

                    <div class="text-14 lh-15 mt-20">
                      <div class="fw-500"><?php echo e(translate('about_restaurant')); ?></div>
                      <div class="text-light-1"><?php echo e(mb_strimwidth($restaurant->description, 0, 80, '...')); ?></div>
                    </div>

                    <div class="text-14 text-green-2 lh-15 mt-10">
                      <div class="fw-500"><?php echo e(translate('free_cancellation')); ?></div>
                      <div class=""><?php echo e(translate('cancel_later')); ?></div>
                    </div>

                    <div class="row x-gap-10 y-gap-10 pt-20">

                    <?php if($restaurant->wifi_availability): ?>
                      <div class="col-auto">
                        <div class="border-light rounded-100 py-5 px-20 text-14 lh-14"><?php echo e(translate('wifi')); ?></div>
                      </div>
                    <?php endif; ?>
                    <?php if($restaurant->parking_availability): ?>

                      <div class="col-auto">
                        <div class="border-light rounded-100 py-5 px-20 text-14 lh-14"><?php echo e(translate('parking')); ?></div>
                      </div>
                    <?php endif; ?>
                    <?php if($restaurant->outdoor_seating): ?>

                      <div class="col-auto">
                        <div class="border-light rounded-100 py-5 px-20 text-14 lh-14"><?php echo e(translate('outdoor_seat')); ?></div>
                      </div>
                    <?php endif; ?>

                      <div class="col-auto">
                        <div class="border-light rounded-100 py-5 px-20 text-14 lh-14"><?php echo e($restaurant->available); ?></div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-auto text-right md:text-left">
                    <!-- <div class="row x-gap-10 y-gap-10 justify-end items-center md:justify-start">
                      <div class="col-auto">
                        <div class="text-14 lh-14 fw-500">Exceptional</div>
                        <div class="text-14 lh-14 text-light-1">3,014 reviews</div>
                      </div>
                      <div class="col-auto">
                        <div class="flex-center text-white fw-600 text-14 size-40 rounded-4 bg-blue-1">4.8</div>
                      </div>
                    </div> -->

                    <div class="">
                      <div class="text-14 text-light-1 mt-50 md:mt-20"><?php echo e(translate('restaurant_menu_start')); ?></div>
                      <div class="text-22 lh-12 fw-600 mt-5">¥<?php echo e($restaurant-> price_range); ?></div>
                      <div class="text-14 text-light-1 mt-5"><?php echo e(translate('taxes_not_included')); ?></div>


                      <a href="<?php echo e(route('restaurant.detail', ['id' => $restaurant->id])); ?>" class="button -md -dark-1 bg-blue-1 text-white mt-24">
                        <?php echo e(translate('see_availability')); ?> <div class="icon-arrow-top-right ml-15"></div>
                      </a>

                    </div>
                  </div>
                </div>
              </div>

            </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


        <div class="border-top-light mt-30 pt-30">
          <div class="row x-gap-10 y-gap-20 justify-between md:justify-center">
            <div class="col-auto md:order-1">
              <button class="button -blue-1 size-40 rounded-full border-light">
                <i class="icon-chevron-left text-12"></i>
              </button>
            </div>

            <div class="col-md-auto md:order-3">
              <div class="row x-gap-20 y-gap-20 items-center md:d-none">

                <div class="col-auto">

                  <div class="size-40 flex-center rounded-full">1</div>

                </div>

                <div class="col-auto">

                  <div class="size-40 flex-center rounded-full bg-dark-1 text-white">2</div>

                </div>

                <div class="col-auto">

                  <div class="size-40 flex-center rounded-full">3</div>

                </div>

                <div class="col-auto">

                  <div class="size-40 flex-center rounded-full bg-light-2">4</div>

                </div>

                <div class="col-auto">

                  <div class="size-40 flex-center rounded-full">5</div>

                </div>

                <div class="col-auto">

                  <div class="size-40 flex-center rounded-full">...</div>

                </div>

                <div class="col-auto">

                  <div class="size-40 flex-center rounded-full">20</div>

                </div>

              </div>

              <div class="row x-gap-10 y-gap-20 justify-center items-center d-none md:d-flex">

                <div class="col-auto">

                  <div class="size-40 flex-center rounded-full">1</div>

                </div>

                <div class="col-auto">

                  <div class="size-40 flex-center rounded-full bg-dark-1 text-white">2</div>

                </div>

                <div class="col-auto">

                  <div class="size-40 flex-center rounded-full">3</div>

                </div>

              </div>

            </div>

            <div class="col-auto md:order-2">
              <button class="button -blue-1 size-40 rounded-full border-light">
                <i class="icon-chevron-right text-12"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php echo $__env->make('includes.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\ticket\e-ticket-main\resources\views/restaurant-list.blade.php ENDPATH**/ ?>