<?php $__env->startSection('content'); ?>
<div class="row y-gap-20 justify-between items-end pb-60 lg:pb-40 md:pb-32">
    <div class="col-auto">
        <h1 class="text-30 lh-14 fw-600"><?php echo e(translate('support_qna')); ?></h1>
    </div>

    <div class="col-auto">
        <a href="<?php echo e(route('createsupport.create')); ?>" class="button h-50 px-24 -dark-1 bg-blue-1 text-white">
            <?php echo e(translate('add_question')); ?> <div class="icon-arrow-top-right ml-15"></div>
        </a>
    </div>
</div>

<div class="py-30 px-30 rounded-4 bg-white shadow-3">
    <div class="tabs -underline-2 js-tabs">
        <div class="tabs__controls row x-gap-40 y-gap-10 lg:x-gap-20 js-tabs-controls">
            <div class="col-auto">
                <button class="tabs__button text-18 lg:text-16 text-light-1 fw-500 pb-5 lg:pb-0 js-tabs-button is-tab-el-active" 
                        data-tab-target=".-tab-item-1">
                        <?php echo e(translate('all_questions')); ?>

                </button>
            </div>
        </div>

        <div class="tabs__content pt-30 js-tabs-content">
            <div class="tabs__pane -tab-item-1 is-tab-el-active">
                <div class="overflow-scroll scroll-bar-1">
                    <table class="table-4 -border-bottom col-12">
                        <thead class="bg-light-2">
                            <tr>
                                <th><?php echo e(translate('name')); ?></th>
                                <th><?php echo e(translate('description')); ?></th>
                                <th><?php echo e(translate('created')); ?></th>
                                <th><?php echo e(translate('action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>   
                                <td class="text-blue-1 fw-500"><?php echo e($question->category->title ?? 'No Category'); ?></td>
                                <td><?php echo e($question->description); ?></td>
                                <td><?php echo e($question->created_at->format('Y-m-d')); ?></td>
                                <td>
                                    <div class="row x-gap-10 y-gap-10 items-center">
                                        <!-- View Button -->
                                        <div class="col-auto">
                                            <a href="<?php echo e(route('createsupport.create', $question->id)); ?>" class="flex-center bg-light-2 rounded-4 size-35">
                                                <i class="icon-eye text-16 text-light-1"></i>
                                            </a>
                                        </div>

                                        <!-- Edit Button -->
                                        <div class="col-auto">
                                            <a href="<?php echo e(route('createsupport.create', $question->id)); ?>">
                                                <button class="flex-center bg-light-2 rounded-4 size-35">
                                                    <i class="icon-edit text-16 text-light-1"></i>
                                                </button>
                                            </a>
                                        </div>

                                        <!-- Delete Button -->
                                        <div class="col-auto">
                                            <form action="<?php echo e(route('question.destroy', $question->id)); ?>" method="POST" 
                                                  onsubmit="return confirm('Are you sure you want to delete this question?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="flex-center bg-light-2 rounded-4 size-35 border-0">
                                                    <i class="icon-trash-2 text-16 text-light-1"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="pt-30">
                        <?php echo e($questions->links()); ?> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('resturant.includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\ticket\e-ticket-main\resources\views/support/support.blade.php ENDPATH**/ ?>