<!DOCTYPE html>
<html>
<head>
    <title>購読確認</title>
</head>
<body>
    <h1>ご購読いただきありがとうございます！</h1>
    <p>最新情報や割引情報を以下のメールアドレスにお送りします: {{ $email }}</p>
</body>
</html>
