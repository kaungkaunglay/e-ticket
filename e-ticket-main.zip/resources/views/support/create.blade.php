@extends('resturant.includes.layout')

@section('content')
<h1>Create</h1>
@endsection
